import sys, json, math, random
sys.path.insert(0, "/home/pizzi/stratfix_work"); sys.path.insert(0, "/home/pizzi/research/t2_regimen")
import numpy as np, pandas as pd
from t2_regime_test import frame, sim_idx, T0_MS, OLD, NEW
CD=6; NREP=100; random.seed(20260913)
def prep(sym):
    m, slm, tpm, fee = frame("V1", sym)
    return dict(H=m["high"].values, L=m["low"].values, C=m["close"].values, A=m["atr"].values, sig=m["sig"].values, ct=m["ct"].values, slm=slm, tpm=tpm, fee=fee, n=len(m))
def run(d, mode, p_trig=None, rng=None):
    out=[]; open_until=-1; block_until=-1
    for i in range(210, d["n"]):
        if not d["sig"][i] or i<=open_until or np.isnan(d["A"][i]) or d["A"][i]<=0: continue
        if mode!="none" and i<=block_until: continue
        g,j=sim_idx(d["H"],d["L"],i,d["C"][i],d["A"][i],d["slm"],d["tpm"])
        if g is None: continue
        r=g-d["fee"]; open_until=j
        if mode=="loss" and r<0: block_until=j+CD
        if mode=="rand" and rng.random()<p_trig: block_until=j+CD
        out.append((i, d["ct"][i], r))
    return out
res={}; pool={"sin":[], "con":[], "plac":[[] for _ in range(NREP)]}
for sym in OLD+NEW:
    d=prep(sym); virgin=(lambda ct: ct<T0_MS) if sym in OLD else (lambda ct: True)
    base=[t for t in run(d,"none") if virgin(t[1])]; con=[t for t in run(d,"loss") if virgin(t[1])]
    p_loss=sum(1 for t in run(d,"none") if t[2]<0)/max(1,len(run(d,"none")))
    plac=[]
    for k in range(NREP):
        rng=random.Random(k*1000+hash(sym)%1000)
        pk=[t for t in run(d,"rand",p_loss,rng) if virgin(t[1])]; plac.append(pk); pool["plac"][k]+=pk
    pool["sin"]+=base; pool["con"]+=con
    import pickle; pickle.dump(dict(base=base,con=con,plac=plac), open(f"pp_{sym}.pkl","wb"))
    ts=100*sum(t[2] for t in base); tc=100*sum(t[2] for t in con); tp=np.array([100*sum(t[2] for t in pk) for pk in plac])
    res[sym]=dict(total_sin=round(ts,1), total_con=round(tc,1), plac_med=round(float(np.median(tp)),1), plac_p5=round(float(np.percentile(tp,5)),1), pct_con_in_plac=round(float((tp<=tc).mean()),3))
    print(f"{sym:10s} sin={ts:+7.1f} con={tc:+7.1f} | placebo med={np.median(tp):+7.1f} p5={np.percentile(tp,5):+7.1f} | con peor que sin: {tc<ts} | con<=med placebo: {tc<=np.median(tp)} | percentil de con en placebo: {(tp<=tc).mean():.3f}", flush=True)
ts=100*sum(t[2] for t in pool["sin"]); tc=100*sum(t[2] for t in pool["con"]); tp=np.array([100*sum(t[2] for t in pk) for pk in pool["plac"]])
a=sum(res[s]["total_con"]<res[s]["total_sin"] for s in res); b1=(tp<=tc).mean()<=0.05; b2=sum(res[s]["total_con"]<=res[s]["plac_med"] for s in res)
# consistencia por año (pool)
ys=pd.DataFrame(pool["sin"],columns=["i","ct","r"]); yc=pd.DataFrame(pool["con"],columns=["i","ct","r"])
ys["y"]=pd.to_datetime(ys.ct,unit="ms").dt.year; yc["y"]=pd.to_datetime(yc.ct,unit="ms").dt.year
yr={}
for y in sorted(ys.y.unique()):
    ns=int((ys.y==y).sum())
    if ns>=100: yr[int(y)]=(round(100*ys[ys.y==y].r.sum(),1), round(100*yc[yc.y==y].r.sum(),1), ns)
c_neg=sum(v[1]<v[0] for v in yr.values()); c=c_neg>len(yr)/2
print(f"\nPOOL virgen: sin={ts:+.1f} con={tc:+.1f} | placebo med={np.median(tp):+.1f} p5={np.percentile(tp,5):+.1f} p95={np.percentile(tp,95):+.1f} | percentil de con={ (tp<=tc).mean():.3f}")
print(f"por año (sin, con, n): {yr} -> con<sin en {c_neg}/{len(yr)} años")
print(f"criterios: a) pares con<sin {a}/8 (>=6:{a>=6}) | b) pool pct<=0.05:{b1} y pares con<=med placebo {b2}/8 (>=6:{b2>=6}) | c) años mayoría:{c}")
print("VEREDICTO:", "QUITAR cooldown V1" if (a>=6 and b1 and b2>=6 and c) else "MANTENER")
json.dump(dict(per=res, pool=dict(sin=ts,con=tc,plac_med=float(np.median(tp)),plac_p5=float(np.percentile(tp,5)),pct=float((tp<=tc).mean())), years=yr), open("t4b_out.json","w"), indent=1)
