# Test 4b — Cooldown 24 h por símbolo, SOLO V1, criterio por pares (pre-registro)
Fecha: 2026-09-13. Declaración honesta: el resultado "peor en 6/8 pares" YA se vio en el test 4; por sí solo no es
evidencia nueva. Para que este test decida algo, añade dos comprobaciones independientes que el test 4 no hizo:
1. **Placebo**: cooldown aleatorio — misma regla (bloqueo 24 h = 6 velas 4h) pero disparado tras operaciones elegidas al
   azar con la misma frecuencia que las pérdidas del par (200 réplicas por par, semilla fija). Si el cooldown real es peor
   que el placebo, el daño viene de bloquear específicamente TRAS PÉRDIDAS (re-entrada en tendencia), no de operar menos.
2. **Consistencia temporal**: diferencia (con − sin) del pool virgen por año natural (años con ≥100 ops).
## Criterio para QUITAR el cooldown de V1 (todo a la vez)
a) total_con < total_sin en ≥6/8 pares (vírgenes) — ya conocido, se re-verifica;
b) placebo: total_con ≤ percentil 5 de la distribución placebo del pool virgen, Y peor que la mediana placebo en ≥6/8 pares;
c) (con − sin) < 0 en la mayoría de los años con ≥100 ops.
Si falla cualquiera → se mantiene. Un "quitar" NO es deploy inmediato: implica backup + dry + validar que el cap
combinado por símbolo (MAX_LOTS_PER_SYMBOL=2) sigue cubriendo el incidente SOL del 06-07.

---
## RESULTADO (2026-09-13; RESULTADOS_20260913.txt, t4b_out.json, pp_*.pkl; NREP=100)
Pool virgen: sin −45.4 % · con −332.9 % · **placebo (cooldown aleatorio, misma frecuencia) mediana −313.3 %**, p5 −511.8,
p95 −115.0 → el cooldown real cae en el **percentil 44** de la distribución placebo. Pares: con<sin 6/8 ✓; con ≤ mediana
placebo solo 5/8 ✗ (ADA/DOGE/BNB mejor que el placebo). Años: con<sin 4/7 ✓ (2020, 2022, 2023, 2026; no en 2021, 2024, 2025).
**VEREDICTO: MANTENER.** El daño de −45 → −333 es casi íntegramente el de "operar menos con V1" (bloquear 24 h tras
CUALQUIER operación hace lo mismo, −313); bloquear específicamente tras pérdidas no añade daño medible. Lección: en V1,
cualquier regla que quite operaciones cuesta dinero en tendencia (dispara en 2/3 de las velas y su valor está en
re-entrar); el cooldown no es peor que otra regla de recorte, pero tampoco protege nada que el cap por símbolo no cubra.
Nota técnica: `pd.to_datetime(...).dt.year` segfaultea en `venv_fix4` (pandas 2.2.3 / py3.14) — la agregación se hizo con
`~/teardown_work/venv`; el script t4b.py murió en silencio dos veces por eso (por-par en pickles).
