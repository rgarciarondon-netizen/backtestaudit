#!/usr/bin/env python3
"""Tesis 2 — gates de régimen sobre V1 (A0) y V2 (L_F1). Ver PREREGISTRO.md."""
import sys, json, time, math
sys.path.insert(0, "/home/pizzi/stratfix_work")
import numpy as np, pandas as pd, ta
import stratfix_v1 as V1, stratfix_v2 as V2
from stratfix_regime_test import fetch_deep, T0_MS, OLD, NEW

SYN = "--synthetic" in sys.argv          # control positivo: gate = conoce el futuro
GATES = ["G1_adx25", "G2_er30", "G3_whipsaw", "G4_btc_ema", "G5_volband"] + (["SYN_future"] if SYN else [])

def sim_idx(H, L, i, entry, atr, slm, tpm):
    sl = entry - slm * atr; tp = entry + tpm * atr
    for j in range(i + 1, len(H)):
        if L[j] <= sl: return sl / entry - 1, j
        if H[j] >= tp: return tp / entry - 1, j
    return None, None

def er(close, n=20):
    ch = (close - close.shift(n)).abs(); vol = close.diff().abs().rolling(n).sum()
    return ch / vol

_btc = None
def btc_regime():
    global _btc
    if _btc is None:
        d = fetch_deep("BTCUSDT", "4h")
        d["e50"] = ta.trend.ema_indicator(d["close"], 50); d["e200"] = ta.trend.ema_indicator(d["close"], 200)
        d["btc_bull"] = d["e50"] > d["e200"]; _btc = d[["ct", "btc_bull"]].sort_values("ct")
    return _btc

def frame(bot, sym):
    if bot == "V1":
        d4 = fetch_deep(sym, "4h"); d1 = fetch_deep(sym, "1h"); m = V1.merged(V1.base_ind(d4), V1.conf_cols(d1))
        m["sig"] = m["A0"].astype(bool); m["adx14"] = ta.trend.ADXIndicator(m["high"], m["low"], m["close"], 14).adx()
        slm, tpm, fee = V1.SL_M, V1.TP_M, V1.FEE_RT
    else:
        d1 = fetch_deep(sym, "1h"); d4 = fetch_deep(sym, "4h"); m = V2.build(d1, d4)
        m["sig"] = m["L_F1"].astype(bool); m["adx14"] = m["adx"]
        slm, tpm, fee = V2.SL_M, V2.TP_M, V2.FEE_RT
    m["er20"] = er(m["close"]); atrp = m["atr"] / m["close"]
    lo = atrp.rolling(500).quantile(0.2).shift(1); hi = atrp.rolling(500).quantile(0.8).shift(1)
    m["volband"] = (atrp >= lo) & (atrp <= hi)
    m = pd.merge_asof(m.sort_values("ct"), btc_regime(), on="ct", direction="backward"); m["btc_bull"] = m["btc_bull"].fillna(False)
    return m, slm, tpm, fee

def trades(bot, sym, only_old):
    """Stream NO solapado: una posición a la vez por símbolo. Devuelve lista de dicts."""
    m, slm, tpm, fee = frame(bot, sym)
    H = m["high"].values; L = m["low"].values; C = m["close"].values; A = m["atr"].values
    sig = m["sig"].values; ct = m["ct"].values; adx = m["adx14"].values; e = m["er20"].values
    vb = m["volband"].values; bb = m["btc_bull"].values
    out = []; open_until = -1; resolved = []   # resolved: (exit_idx, was_sl)
    for i in range(210, len(m)):
        if not sig[i] or i <= open_until: continue
        if np.isnan(A[i]) or A[i] <= 0 or np.isnan(adx[i]) or np.isnan(e[i]): continue
        g, j = sim_idx(H, L, i, C[i], A[i], slm, tpm)
        if g is None: continue
        r = g - fee; open_until = j
        last2 = [s for (x, s) in resolved if x < i][-2:]
        whip = len(last2) == 2 and all(last2)
        rec = dict(sym=sym, ct=int(ct[i]), r=r, virgin=(ct[i] < T0_MS) if only_old else True,
                   G1_adx25=bool(adx[i] >= 25), G2_er30=bool(e[i] >= 0.30), G3_whipsaw=(not whip),
                   G4_btc_ema=bool(bb[i]), G5_volband=bool(vb[i]))
        if SYN: rec["SYN_future"] = bool(g > 0)
        out.append(rec); resolved.append((j, g < 0))
    return out

def tstat(x):
    x = np.asarray(x); n = len(x)
    return float(x.mean() / (x.std(ddof=1) / math.sqrt(n))) if n > 2 and x.std(ddof=1) > 0 else float("nan")

def evaluate(bot, allt):
    v = [t for t in allt if t["virgin"]]
    res = {}
    for g in GATES:
        gated = [t["r"] for t in v if t[g]]; excl = [t["r"] for t in v if not t[g]]; alls = [t["r"] for t in v]
        e_all = 100 * np.mean(alls); e_g = 100 * np.mean(gated) if gated else float("nan"); e_x = 100 * np.mean(excl) if excl else float("nan")
        cov = len(gated) / len(alls); tg = tstat(gated) if gated else float("nan")
        wins = 0; per = {}
        for s in NEW:
            ps = [t for t in v if t["sym"] == s]; pg = [t["r"] for t in ps if t[g]]
            if ps and pg:
                per[s] = (round(100 * np.mean([t["r"] for t in ps]), 3), round(100 * np.mean(pg), 3), len(pg))
                wins += per[s][1] > per[s][0]
        a = e_g > e_all and wins >= 4; b = e_g > 0 and tg >= 2.5; c = cov >= 0.25; d = len(gated) >= 200
        verdict = "GO" if (a and b and c and d) else ("LEAD" if (a and c and d) else "KILL")
        res[g] = dict(n_all=len(alls), n_gated=len(gated), cov=round(cov, 3), exp_all=round(e_all, 3), exp_gated=round(e_g, 3),
                      exp_excl=round(e_x, 3), t_gated=round(tg, 2), new_pairs_win=f"{wins}/{len(per)}", per_new=per,
                      crit=dict(a=a, b=b, c=c, d=d), VEREDICTO=verdict)
        print(f"[{bot}] {g:11s} n={len(alls):5d}→{len(gated):5d} cov={cov:.2f} | exp all={e_all:+.3f} gated={e_g:+.3f} excl={e_x:+.3f} t_gated={tg:.2f} | nuevos {wins}/{len(per)} | {verdict}")
    # informativo: contaminado (BTC/ETH/SOL últimos 36m)
    cont = [t for t in allt if not t["virgin"]]
    if cont:
        line = " | ".join(f"{g}: {100*np.mean([t['r'] for t in cont if t[g]]):+.3f}(n={sum(t[g] for t in cont)})" for g in GATES)
        print(f"[{bot}] contaminado 36m (informativo): all={100*np.mean([t['r'] for t in cont]):+.3f}(n={len(cont)}) | {line}")
    return res

def main():
    out = {"asof": time.strftime("%F %T"), "synthetic": SYN}
    for bot in ("V1", "V2"):
        allt = []
        for sym in OLD + NEW:
            tr = trades(bot, sym, only_old=(sym in OLD)); allt += tr
            print(f"  {bot} {sym}: {len(tr)} ops no solapadas ({sum(t['virgin'] for t in tr)} vírgenes)", flush=True)
        out[bot] = evaluate(bot, allt)
    json.dump(out, open("t2_out_synthetic.json" if SYN else "t2_out.json", "w"), indent=1, default=lambda o: bool(o) if isinstance(o, np.bool_) else str(o))

if __name__ == "__main__":
    main()
