# Test 4 — Cooldown 24 h por símbolo tras cierre en pérdida (pre-registro)
Fecha: 2026-09-13, antes de correr. Regla VIVA desde 06-07 en ambos bots ([[bot-cooldown-per-symbol-lead]]): tras un cierre
en pérdida en un símbolo, no se abren entradas nuevas en ese símbolo durante 24 h contadas desde el cierre.
Pregunta: ¿suma o resta? La tesis 2 (G3, regla distinta: saltar tras 2 SL) sugirió que resta; esto prueba la regla exacta.

## Método
- Engines auditados (`~/stratfix_work`): V1 A0 long 4h (cooldown = 6 velas), V2 L_F1 long 1h (24 velas). Fees 0.2 % rt,
  SL/TP vivos. Datos vírgenes = contrato 19-07 (BTC/ETH/SOL ct<T0 + ADA/DOGE/PEPE/BNB/XRP completos); 36 m recientes
  de BTC/ETH/SOL = informativo. Stream no solapado por símbolo (una posición a la vez).
- Dos simulaciones por par: SIN cooldown (baseline) y CON cooldown (la regla viva, aplicada al cierre de cada pérdida).
- Métricas: total neto (%) y exp/op de cada stream; nº de ops; y el "conjunto saltado" = ops del stream baseline cuya
  entrada cae dentro de una ventana de cooldown → exp/op y t de ese conjunto (si es >0, el cooldown tira dinero).
## Veredicto (por bot, pool virgen)
- **RESTA** si total_con < total_sin en el pool Y en ≥3/5 pares nuevos Y exp del conjunto saltado > 0.
- **SUMA** si total_con > total_sin en el pool Y en ≥3/5 pares nuevos Y exp del conjunto saltado < 0.
- **INCONCLUSO** en otro caso. La decisión de quitar la regla viva exige RESTA en AMBOS bots o RESTA con t≥2 del
  conjunto saltado en uno; no se cambia nada con INCONCLUSO.

---
## RESULTADO (2026-09-13; RESULTADOS_20260913.txt, t4_out.json; venv ~/hedge_s2/backtest/venv_fix4)
| Bot | stream | n | total neto | exp/op | conjunto saltado | pares nuevos con<sin | Veredicto pre-reg |
|---|---|---|---|---|---|---|---|
| V1 | SIN cooldown | 3622 | −45.4 % | −0.013 % | n=1512, exp **+0.189 %**, t 0.95 | 3/5 | **RESTA** |
| V1 | CON cooldown | 3147 | **−332.9 %** | −0.106 % | | | |
| V2 | SIN cooldown | 1484 | −468.3 % | −0.316 % | n=226, exp −0.227 %, t −2.09 | 0/5 (5/5 con>sin) | **SUMA** |
| V2 | CON cooldown | 1276 | −418.5 % | −0.328 % | | | |

V1: peor en BTC/ETH/SOL vírgenes (3/3, p.ej. ETH +100 → −58) y en los 36 m recientes (3/3), y en 3/5 nuevos. Mecanismo
visible: V1 dispara en ~2/3 de las velas; su parte buena en tendencia es re-entrar enseguida tras un SL, y el cooldown lo
prohíbe. Lo saltado es positivo pero con t 0.95 (colas anchas: PEPE/SOL).
V2: "SUMA" solo porque quita operaciones de una entrada negativa en todo régimen; lo saltado (−0.227) es MENOS malo que la
media (−0.316) → el cooldown NO discrimina en V2, cualquier recorte aleatorio de 208 ops habría mejorado más.
**Decisión según pre-registro: NO se cambia la regla viva** (exige RESTA en ambos, o RESTA con t≥2 en uno; hay RESTA
V1 con t 0.95 y SUMA-por-recorte en V2). La evidencia se inclina a que en V1 resta; queda anotado, no ejecutado.
