import sys, json, math
sys.path.insert(0, "/home/pizzi/stratfix_work"); sys.path.insert(0, "/home/pizzi/research/t2_regimen")
import numpy as np
from t2_regime_test import frame, sim_idx, T0_MS, OLD, NEW
CD = {"V1": 6, "V2": 24}   # velas de 24h

def streams(bot, sym, only_old):
    m, slm, tpm, fee = frame(bot, sym)
    H=m["high"].values; L=m["low"].values; C=m["close"].values; A=m["atr"].values; sig=m["sig"].values; ct=m["ct"].values
    def run(cooldown):
        out=[]; open_until=-1; block_until=-1
        for i in range(210, len(m)):
            if not sig[i] or i<=open_until or np.isnan(A[i]) or A[i]<=0: continue
            if cooldown and i<=block_until: continue
            g,j=sim_idx(H,L,i,C[i],A[i],slm,tpm)
            if g is None: continue
            r=g-fee; open_until=j
            if cooldown and r<0: block_until=j+CD[bot]
            out.append(dict(i=i, j=j, r=r, virgin=(ct[i]<T0_MS) if only_old else True))
        return out
    base=run(False); cd=run(True)
    # conjunto saltado: ops del baseline cuya entrada cae dentro de (j_perdida, j_perdida+CD] de una pérdida PREVIA del baseline
    skipped=[]; block=-1
    for t in base:
        if t["i"]<=block: skipped.append(t)
        if t["r"]<0: block=t["j"]+CD[bot]
    return base, cd, skipped

def tstat(x): x=np.asarray(x); return float(x.mean()/(x.std(ddof=1)/math.sqrt(len(x)))) if len(x)>2 else float("nan")
res={}
for bot in ("V1","V2"):
    P={"base":[], "cd":[], "skip":[]}; per={}
    for sym in OLD+NEW:
        b,c,s=streams(bot, sym, sym in OLD)
        bv=[t["r"] for t in b if t["virgin"]]; cv=[t["r"] for t in c if t["virgin"]]; sv=[t["r"] for t in s if t["virgin"]]
        P["base"]+=bv; P["cd"]+=cv; P["skip"]+=sv
        per[sym]=dict(n_sin=len(bv), n_con=len(cv), total_sin=round(100*sum(bv),1), total_con=round(100*sum(cv),1), exp_skip=round(100*np.mean(sv),3) if sv else None, n_skip=len(sv))
        if sym in OLD:
            bc=[t["r"] for t in b if not t["virgin"]]; cc=[t["r"] for t in c if not t["virgin"]]; sc=[t["r"] for t in s if not t["virgin"]]
            per[sym]["contaminado"]=dict(total_sin=round(100*sum(bc),1), total_con=round(100*sum(cc),1), exp_skip=round(100*np.mean(sc),3) if sc else None, n_skip=len(sc))
    tb=100*sum(P["base"]); tc=100*sum(P["cd"]); es=100*np.mean(P["skip"]); ts=tstat(P["skip"])
    new_less=sum(per[s]["total_con"]<per[s]["total_sin"] for s in NEW); new_more=sum(per[s]["total_con"]>per[s]["total_sin"] for s in NEW)
    if tc<tb and new_less>=3 and es>0: v="RESTA"
    elif tc>tb and new_more>=3 and es<0: v="SUMA"
    else: v="INCONCLUSO"
    print(f"[{bot}] pool virgen: SIN n={len(P['base'])} total={tb:+.1f}% exp={100*np.mean(P['base']):+.3f} | CON n={len(P['cd'])} total={tc:+.1f}% exp={100*np.mean(P['cd']):+.3f} | SALTADAS n={len(P['skip'])} exp={es:+.3f}% t={ts:.2f} | nuevos con<sin {new_less}/5 | {v}")
    for s in OLD+NEW: print("   ", s, json.dumps(per[s]))
    res[bot]=dict(pool=dict(n_sin=len(P["base"]), total_sin=round(tb,1), n_con=len(P["cd"]), total_con=round(tc,1), n_skip=len(P["skip"]), exp_skip=round(es,3), t_skip=round(ts,2)), per=per, VEREDICTO=v)
json.dump(res, open("t4_out.json","w"), indent=1)
