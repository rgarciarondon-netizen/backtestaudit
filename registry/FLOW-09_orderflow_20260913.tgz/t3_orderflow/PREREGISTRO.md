# Tesis 3 — Order-flow con taker_buy (CVD-proxy) (pre-registro)
Fecha: 2026-09-13, escrito ANTES de calcular nada. Datos: los mismos parquet 1h de perpetuos mainnet (BTC/ETH/SOL,
2021-09-13 → 2026-09-13) de la tesis 1, que traen `taker_buy_base_volume`. Todo se calcula solo con velas cerradas.

## Features
- Imbalance por vela: imb = (taker_buy − taker_sell) / volumen = 2·tbv/v − 1.
- Flujo 24h: F24 = suma de (taker_buy − taker_sell) de las últimas 24 velas, normalizada por la suma de volumen 24h.
- z-score de F24 contra su media/desv. móvil de 90 días (2160 velas), calculadas con ventana pasada (shift 1).
- CVD24 = suma móvil 24h de (taker_buy − taker_sell) en unidades base.

## Reglas (parámetros fijados ahora; sin escaneo)
- **R1 Continuación de flujo** (primaria; mecanismo: flujo agresivo informado persiste): z ≥ +1.5 → long; z ≤ −1.5 → short.
- **R2 Reversión de flujo** (alternativa declarada, signo opuesto a R1; mecanismo: agresión retail/liquidaciones
  sobre-reaccionan). Se evalúa con los mismos criterios; al ser dos tests de signo opuesto, el listón t≥2.5 aplica.
- **R3 Divergencia precio/flujo**: cierre = mínimo de 24 velas Y CVD24 > mediana de sus últimas 24 → long;
  cierre = máximo de 24 Y CVD24 < mediana → short.
- Horizonte de decisión: **12 velas (12 h)**, entrada al cierre de la vela de señal, salida al cierre 12 velas después.
  Horizontes 4 h y 24 h se reportan como informativos. Una posición a la vez por par (no solapado).

## Coste y ajuste por deriva
- Coste 0.12 % round-trip (taker+slippage), variante maker 0.06 % informativa.
- **Exceso sobre deriva**: a cada operación se le resta el retorno medio a 12 h del par en ese mismo año natural
  (con signo de la operación). Evita que un long-only "gane" por montar la subida de BTC. Decide el **exceso neto**.

## Criterio de MUERTE (por regla; cualquiera mata)
1. Exceso neto medio ≤ 0 en el pool 3 pares.  2. Exceso neto ≤ 0 en alguno de 2022-2025.
3. Exceso neto ≤ 0 en ≥2 de 3 pares.  4. t del exceso neto < 2.5.  5. n < 150 operaciones en el pool.
Long y short se reportan por separado; el veredicto es sobre el conjunto. "Fee-bound" se anota si gross-exceso > 0
con t≥2.5 y todos los años pero neto ≤ 0 a 0.12 % y > 0 a 0.06 %.
Control positivo: inyectar +50 bp en las operaciones de R1 debe dar GO.

---
## RESULTADO (2026-09-13; salida íntegra en RESULTADOS_20260913.txt; venv ~/teardown_work/venv)
Control positivo: +50 bp inyectados en R1 a 12 h → GO (t 8.3). Evaluador válido.

| Regla | n | exceso gross 12h | exceso NETO 12h | t | años 2022-25 neto>0 | pares >0 | Veredicto |
|---|---|---|---|---|---|---|---|
| R1 continuación de flujo | 2614 | +7.3 bp (t 1.33) | −4.7 bp | −0.86 | 1/4 | 1/3 | **KILL** |
| R2 reversión de flujo | 2614 | −7.3 bp | −19.3 bp | −3.53 | 0/4 | 0/3 | **KILL** (con t −3.5: fade del flujo PIERDE con confianza) |
| R3 divergencia precio/CVD | 1911 | +3.2 bp (t 0.47) | −8.8 bp | −1.28 | 2/4 | 0/3 | **KILL** |

Informativo (horizonte NO decisor, visto después de correr → NO se rescata): R1 a 24 h exceso gross +18.2 bp (t 2.44),
neto taker +6.2 bp (t 0.83), neto maker +12.2 bp. Es el efecto gross más grande de todo el programa I+D y crece con el
horizonte (4h +5.6 → 12h +7.3 → 24h +18.2), coherente con "flujo agresivo informado persiste". Queda como **lead
condicionado**: solo puede reevaluarse con un pre-registro nuevo a 24-48 h sobre datos que NO haya visto este test
(ADA/DOGE/BNB/XRP/PEPE perp), sin tocar el umbral z=1.5. Tesis 3 CERRADA como KILL en el horizonte pre-registrado.
