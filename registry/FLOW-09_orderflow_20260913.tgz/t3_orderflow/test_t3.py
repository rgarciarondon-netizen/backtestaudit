import sys, numpy as np, pandas as pd
COST=0.0012; COSTM=0.0006; SYMS=["BTCUSDT","ETHUSDT","SOLUSDT"]; H_DEC=12; HS=[4,12,24]
SYN="--synthetic" in sys.argv
def load(s):
    k=pd.read_parquet(f"../t1_horario/{s}_1h.parquet")[["o","h","l","c","v","tbv"]].copy()
    k["ts"]=k.tbv; k["tsv"]=k.v-k.tbv; k["d"]=k.ts-k.tsv
    k["F24"]=k.d.rolling(24).sum()/k.v.rolling(24).sum()
    mu=k.F24.rolling(2160).mean().shift(1); sd=k.F24.rolling(2160).std().shift(1); k["z"]=(k.F24-mu)/sd
    k["cvd24"]=k.d.rolling(24).sum(); k["cvd_med"]=k.cvd24.rolling(24).median().shift(1)
    k["lo24"]=k.c.rolling(24).min(); k["hi24"]=k.c.rolling(24).max()
    for h in HS: k[f"fwd{h}"]=k.c.shift(-h)/k.c-1
    k["year"]=k.index.year
    return k
K={s:load(s) for s in SYMS}
DRIFT={(s,y,h):K[s][K[s].year==y][f"fwd{h}"].mean() for s in SYMS for y in K[s].year.unique() for h in HS}

def signals(k, rule):
    if rule=="R1": return np.where(k.z>=1.5,1,np.where(k.z<=-1.5,-1,0))
    if rule=="R2": return np.where(k.z>=1.5,-1,np.where(k.z<=-1.5,1,0))
    if rule=="R3":
        lg=(k.c<=k.lo24)&(k.cvd24>k.cvd_med); sh=(k.c>=k.hi24)&(k.cvd24<k.cvd_med)
        return np.where(lg,1,np.where(sh,-1,0))

def trades(rule):
    rows=[]
    for s in SYMS:
        k=K[s]; sig=signals(k,rule); idx=k.index; busy=-1
        for i in range(2200,len(k)-24):
            if sig[i]==0 or i<=busy: continue
            d=int(sig[i]); busy=i+H_DEC
            rec=dict(sym=s,t=idx[i],dir=d,year=idx[i].year)
            for h in HS:
                g=d*k[f"fwd{h}"].iat[i]; rec[f"g{h}"]=g; rec[f"x{h}"]=g-d*DRIFT[(s,idx[i].year,h)]
            if SYN: rec["g12"]+=0.005; rec["x12"]+=0.005
            rows.append(rec)
    return pd.DataFrame(rows)

def tstat(x): x=np.asarray(x); return x.mean()/(x.std(ddof=1)/np.sqrt(len(x))) if len(x)>2 else np.nan
def report(rule, tr):
    print(f"\n== {rule}: n={len(tr)} (long {int((tr.dir==1).sum())} / short {int((tr.dir==-1).sum())})")
    if len(tr)==0: print("   sin operaciones -> KILL"); return
    for h in HS:
        xn=tr[f"x{h}"]-COST; tag="DECIDE" if h==H_DEC else "info"
        print(f"   H={h:2d}h [{tag}] gross={tr[f'g{h}'].mean()*1e4:+.1f}bp exceso={tr[f'x{h}'].mean()*1e4:+.1f}bp (t={tstat(tr[f'x{h}']):.2f}) | EXCESO NETO={xn.mean()*1e4:+.1f}bp (t={tstat(xn):.2f}) maker={ (tr[f'x{h}']-COSTM).mean()*1e4:+.1f}bp")
    xn=tr[f"x{H_DEC}"]-COST
    yr={int(y):round(v*1e4,1) for y,v in xn.groupby(tr.year).mean().items()}; ps={s:round(v*1e4,1) for s,v in xn.groupby(tr.sym).mean().items()}
    ld={int(d):round(v*1e4,1) for d,v in xn.groupby(tr.dir).mean().items()}
    print(f"   12h exceso neto por año: {yr} | por par: {ps} | por lado: {ld}")
    years=[y for y in (2022,2023,2024,2025) if y in yr]
    k1=xn.mean()<=0; k2=any(yr[y]<=0 for y in years); k3=sum(v<=0 for v in ps.values())>=2; k4=not(tstat(xn)>=2.5); k5=len(tr)<150
    v="KILL" if (k1 or k2 or k3 or k4 or k5) else "GO"
    xg=tr[f"x{H_DEC}"]
    if v=="KILL" and xg.mean()>0 and tstat(xg)>=2.5 and all(xg[tr.year==y].mean()>0 for y in years) and (xg-COSTM).mean()>0: v="KILL (fee-bound)"
    print(f"   criterios: neto<=0:{k1} año<=0:{k2} >=2pares<=0:{k3} t<2.5:{k4} n<150:{k5} -> {v}")
for r in ("R1","R2","R3"): report(r, trades(r))
