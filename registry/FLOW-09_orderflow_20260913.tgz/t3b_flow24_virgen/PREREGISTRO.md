# Tesis 3b — Continuación de flujo a 24 h en pares vírgenes (pre-registro)
Fecha: 2026-09-13, antes de descargar. Reevaluación del lead de la tesis 3 con datos que ese test NO vio.
- Pares: ADAUSDT, DOGEUSDT, BNBUSDT, XRPUSDT, 1000PEPEUSDT (perp USDT-M mainnet, 1h, historia disponible hasta 2026-09-13,
  desde 2021-09-13 o el listado). NO se usan BTC/ETH/SOL.
- Regla ÚNICA, sin cambios: F24 = flujo taker neto 24h / volumen 24h; z contra media/desv móvil 90 d (shift 1);
  z ≥ +1.5 → long, z ≤ −1.5 → short. Entrada al cierre de la vela de señal, salida 24 velas después.
  Una posición a la vez por par. Horizonte 48 h informativo.
- Exceso sobre deriva: se resta el retorno medio a 24 h del par en ese año natural (con signo).
- Coste decisor: **maker 0.06 %** (declarado en el lead); taker 0.12 % se reporta y se comenta.
## Muerte (cualquiera)
1. Exceso neto (maker) medio ≤ 0 en el pool.  2. ≤ 0 en algún año completo con ≥100 ops en el pool (2022-2025).
3. ≤ 0 en 2 o más pares de 5.  4. t < 2.5.  5. n < 150.
GO = ninguna de las anteriores. Un GO NO es deploy: abre walk-forward + paper en demo con órdenes maker reales (el
supuesto de fill maker a 24 h es la debilidad declarada de la regla).
Control positivo: +50 bp inyectados → debe dar GO.

---
## RESULTADO (2026-09-13; RESULTADOS_20260913.txt)
Datos: 5 pares perp 1h, 0 huecos (PEPE desde 2023-05). n=2773 ops (1401 long / 1372 short).
Control positivo: +50 bp → KILL solo por el criterio "algún año ≤0" (2023 tiene un agujero de −58 bp que +50 no cubre);
+100 bp → GO (t 9.9). El evaluador puede decir sí; el criterio anual es estricto por diseño.

| Horizonte | exceso gross | neto maker | t maker | neto taker |
|---|---|---|---|---|
| **24 h (decide)** | **−2.7 bp (t −0.29)** | −8.7 bp | −0.94 | −14.7 bp |
| 48 h (info) | +19.9 bp (t 1.57) | +13.9 bp | 1.09 | +7.9 bp |

Por año (neto maker): 2022 −2.1 · 2023 −57.6 · 2024 −12.7 · 2025 +15.5. Por par: PEPE +11, ADA +10, DOGE +5, BNB −22, XRP −44.
Por lado: long +7, short −25.
**KILL.** El +18 bp a 24 h de BTC/ETH/SOL NO replica en pares vírgenes (−2.7 bp): era ruido de selección de horizonte.
El +20 bp a 48 h (t 1.6) es de nuevo un horizonte desplazado visto post-hoc; no se persigue. Lead CERRADO.
