import sys, numpy as np, pandas as pd
COSTM=0.0006; COSTT=0.0012; SYMS=["ADAUSDT","DOGEUSDT","BNBUSDT","XRPUSDT","1000PEPEUSDT"]; H=24; HS=[24,48]
SYN="--synthetic" in sys.argv
def load(s):
    k=pd.read_parquet(f"{s}_1h.parquet")[["c","v","tbv"]].copy(); k["d"]=2*k.tbv-k.v
    k["F24"]=k.d.rolling(24).sum()/k.v.rolling(24).sum()
    mu=k.F24.rolling(2160).mean().shift(1); sd=k.F24.rolling(2160).std().shift(1); k["z"]=(k.F24-mu)/sd
    for h in HS: k[f"fwd{h}"]=k.c.shift(-h)/k.c-1
    k["year"]=k.index.year; return k
K={s:load(s) for s in SYMS}
DRIFT={(s,y,h):K[s][K[s].year==y][f"fwd{h}"].mean() for s in SYMS for y in K[s].year.unique() for h in HS}
rows=[]
for s in SYMS:
    k=K[s]; z=k.z.values; idx=k.index; busy=-1
    for i in range(2200,len(k)-48):
        d=1 if z[i]>=1.5 else (-1 if z[i]<=-1.5 else 0)
        if d==0 or i<=busy: continue
        busy=i+H; rec=dict(sym=s,t=idx[i],dir=d,year=idx[i].year)
        for h in HS: rec[f"x{h}"]=d*k[f"fwd{h}"].iat[i]-d*DRIFT[(s,idx[i].year,h)]
        if SYN: rec["x24"]+=0.005
        rows.append(rec)
tr=pd.DataFrame(rows)
def t(x): x=np.asarray(x); return x.mean()/(x.std(ddof=1)/np.sqrt(len(x)))
print(f"n={len(tr)} long={int((tr.dir==1).sum())} short={int((tr.dir==-1).sum())}")
for h in HS:
    x=tr[f"x{h}"]; print(f"H={h}h exceso gross={x.mean()*1e4:+.1f}bp (t={t(x):.2f}) | neto MAKER={(x-COSTM).mean()*1e4:+.1f}bp (t={t(x-COSTM):.2f}) | neto taker={(x-COSTT).mean()*1e4:+.1f}bp (t={t(x-COSTT):.2f})")
xn=tr.x24-COSTM
yr=xn.groupby(tr.year).agg(["mean","count"]); yr["mean"]*=1e4
ps={s:round(v*1e4,1) for s,v in xn.groupby(tr.sym).mean().items()}; ld={int(d):round(v*1e4,1) for d,v in xn.groupby(tr.dir).mean().items()}
print("por año (neto maker bp, n):", {int(y):(round(r["mean"],1),int(r["count"])) for y,r in yr.iterrows()}); print("por par:", ps, "| por lado:", ld)
years=[y for y in (2022,2023,2024,2025) if y in yr.index and yr.loc[y,"count"]>=100]
k1=xn.mean()<=0; k2=any(yr.loc[y,"mean"]<=0 for y in years); k3=sum(v<=0 for v in ps.values())>=2; k4=not(t(xn)>=2.5); k5=len(tr)<150
print(f"criterios: neto<=0:{k1} año<=0:{k2} >=2pares<=0:{k3} t<2.5:{k4} n<150:{k5} -> {'KILL' if (k1 or k2 or k3 or k4 or k5) else 'GO'}")
