import requests, time, pandas as pd
START = int(pd.Timestamp("2021-09-13", tz="UTC").timestamp()*1000); END = int(pd.Timestamp("2026-09-13", tz="UTC").timestamp()*1000)
S = requests.Session()
def klines(sym):
    rows=[]; t=START
    while t < END:
        r=S.get("https://fapi.binance.com/fapi/v1/klines", params=dict(symbol=sym, interval="1h", startTime=t, limit=1500), timeout=30); r.raise_for_status()
        b=r.json()
        if not b: break
        rows+=b; t=b[-1][0]+3600_000; time.sleep(0.15)
    df=pd.DataFrame(rows, columns=["t","o","h","l","c","v","ct","qv","n","tbv","tbqv","x"])
    df=df.drop_duplicates("t").astype({"o":float,"h":float,"l":float,"c":float,"v":float,"tbv":float})
    df["t"]=pd.to_datetime(df["t"], unit="ms", utc=True); return df[df.t < pd.Timestamp(END, unit="ms", tz="UTC")].set_index("t")
for sym in ["ADAUSDT","DOGEUSDT","BNBUSDT","XRPUSDT","1000PEPEUSDT"]:
    k=klines(sym); k.to_parquet(f"{sym}_1h.parquet")
    idx=pd.date_range(k.index.min(), k.index.max(), freq="1h", tz="UTC")
    print(sym, len(k), k.index.min().date(), k.index.max().date(), "gaps", len(idx)-len(k), "zerov", int((k.v==0).sum()), "bad", int(((k.h<k.l)|(k.c<=0)).sum()), flush=True)
